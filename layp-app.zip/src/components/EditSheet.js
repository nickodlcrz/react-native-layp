import React, { useEffect, useState } from "react";
import { Modal, View, Text, Pressable, ScrollView, StyleSheet, Dimensions, KeyboardAvoidingView, Platform } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  runOnJS,
  Easing,
} from "react-native-reanimated";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { X } from "lucide-react-native";
import { useTheme } from "../theme";
import { DURATION, SPRING } from "../animation";

const { height: SCREEN_H } = Dimensions.get("window");
const DISMISS_DISTANCE = 120;
const DISMISS_VELOCITY = 900;
// expo-blur's default Android implementation doesn't actually blur the
// content behind it (Android has no equivalent of iOS's native
// UIVisualEffectView) -- it just tints, which reads as "the backdrop isn't
// blurred at all" next to iOS. "dimezisBlurView" opts into a real
// view-snapshot blur on Android instead. iOS needs no override.
const ANDROID_BLUR_METHOD = "dimezisBlurView";

// A single reusable "editing surface": instead of a form squeezed inline
// into a list (the old pattern), whatever's being edited -- a task's
// deadline, an expense -- gets its own focused popup. The rest of the
// screen dims and blurs behind it so attention stays on the one thing
// being edited, and the sheet can be dragged back down to cancel, the
// same way a native bottom sheet works.
//
// Used identically by Todo (editing a task) and Spending (editing an
// expense) so both features share one animation implementation instead of
// each screen inventing its own.
export default function EditSheet({ visible, onClose, title, children, maxHeightRatio = 0.86 }) {
  const { theme } = useTheme();
  const [mounted, setMounted] = useState(visible);
  const progress = useSharedValue(0); // 0 = fully hidden, 1 = fully shown
  const dragY = useSharedValue(0);

  useEffect(() => {
    if (visible) {
      setMounted(true);
      dragY.value = 0;
      progress.value = withTiming(1, { duration: DURATION, easing: Easing.out(Easing.cubic) });
    } else {
      progress.value = withTiming(0, { duration: DURATION, easing: Easing.in(Easing.cubic) }, (finished) => {
        if (finished) runOnJS(setMounted)(false);
      });
    }
  }, [visible]);

  function requestClose() {
    onClose && onClose();
  }

  const backdropStyle = useAnimatedStyle(() => ({
    opacity: progress.value,
  }));

  const sheetStyle = useAnimatedStyle(() => ({
    opacity: progress.value,
    transform: [
      { translateY: (1 - progress.value) * 80 + dragY.value },
    ],
  }));

  // Dragging the sheet itself down (from the handle/header area) cancels
  // the edit -- release far or fast enough and it slides the rest of the
  // way off before actually closing, otherwise it springs back into place.
  const pan = Gesture.Pan()
    .onUpdate((e) => {
      if (e.translationY > 0) dragY.value = e.translationY;
    })
    .onEnd((e) => {
      if (e.translationY > DISMISS_DISTANCE || e.velocityY > DISMISS_VELOCITY) {
        dragY.value = withTiming(SCREEN_H, { duration: DURATION, easing: Easing.in(Easing.cubic) }, (finished) => {
          if (finished) runOnJS(requestClose)();
        });
      } else {
        dragY.value = withSpring(0, SPRING);
      }
    });

  if (!mounted) return null;

  return (
    <Modal visible transparent animationType="none" statusBarTranslucent onRequestClose={requestClose}>
      <Animated.View style={[StyleSheet.absoluteFillObject, backdropStyle]}>
        <Pressable style={StyleSheet.absoluteFillObject} onPress={requestClose} accessibilityLabel="Close">
          <View style={[StyleSheet.absoluteFillObject, { backgroundColor: "rgba(0,0,0,0.62)" }]} />
        </Pressable>
      </Animated.View>

      <KeyboardAvoidingView
        style={styles.centerWrap}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        pointerEvents="box-none"
      >
        <Animated.View
          style={[
            styles.sheet,
            { maxHeight: SCREEN_H * maxHeightRatio },
            sheetStyle,
          ]}
        >
          <View style={[styles.solidSheet, { backgroundColor: theme.card, borderColor: theme.line }]}>
          <GestureDetector gesture={pan}>
            <View>
              <View style={[styles.handle, { backgroundColor: theme.line }]} />
              {title ? (
                <View style={styles.header}>
                  <Text style={[styles.title, { color: theme.text }]}>{title}</Text>
                  <Pressable onPress={requestClose} hitSlop={10} accessibilityLabel="Close">
                    <X size={18} color={theme.textMuted} />
                  </Pressable>
                </View>
              ) : null}
            </View>
          </GestureDetector>
          <ScrollView
            style={styles.scroll}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}
          >
            {children}
          </ScrollView>
          </View>
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  centerWrap: { flex: 1, justifyContent: "flex-end" },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderBottomWidth: 0,
    overflow: "hidden",
    // Shadow so the sheet reads as lifted above the blurred backdrop, not
    // flush with it.
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 10,
  },
  // flexShrink (NOT flex:1): the sheet is auto-height with only a maxHeight,
  // so a flex:1 child collapses to nothing and the whole editor gets cut
  // off. flexShrink lets it size to its content and only scroll once it
  // reaches maxHeight.
  solidSheet: {
    flexShrink: 1,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 8,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderBottomWidth: 0,
    overflow: "hidden",
  },
  scroll: { flexGrow: 0, flexShrink: 1 },
  handle: {
    alignSelf: "center",
    width: 36,
    height: 4,
    borderRadius: 2,
    marginTop: 4,
    marginBottom: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
    paddingBottom: 8,
  },
  title: { fontSize: 16, fontWeight: "700" },
  scrollContent: { paddingBottom: 36 },
});
